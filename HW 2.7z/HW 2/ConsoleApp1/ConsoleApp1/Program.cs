﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int x, c, v, b, otic, pol, A, B;
            pol = 0;
            otic = 0;
            Console.Write("Vvedite x: ");
            x = Convert.ToInt32(Console.ReadLine());
            if (x > 0)
                x++;
            else if (x < 0)
                x = x - 2;
            else if (x == 0)
                x = 10;
            Console.WriteLine(x);

            Console.WriteLine("Введите три числа: ");
            Console.Write("Vvedite c: ");
            c = Convert.ToInt32(Console.ReadLine());
            Console.Write("Vvedite v: ");
            v = Convert.ToInt32(Console.ReadLine());
            Console.Write("Vvedite b: ");
            b = Convert.ToInt32(Console.ReadLine());
            if (c >= 0)
            {
                pol++;
                Console.WriteLine("c polozitelnoe");
            }
            else
            {
                Console.WriteLine("c otricatelnoe");
                otic++;
            }
            if (v >= 0)
            {
                pol++;
                Console.WriteLine("v polozitelnoe");
            }
            else
            {
                otic++;
                Console.WriteLine("v otricatelnoe");
            }
            if (b >= 0)
            {
                pol++;
                Console.WriteLine("b polozitelnoe");
            }
            else
            {
                otic++;
                Console.WriteLine("b otricatelnoe");
            }
            Console.WriteLine("Количество положительных чисел = " + pol);
            Console.WriteLine("Количество отрицательных чисел = " + otic);


            Console.Write("Vvedite A: ");
            A = Convert.ToInt32(Console.ReadLine()); 
            Console.Write("Vvedite B: ");
            B = Convert.ToInt32(Console.ReadLine());


            Console.ReadKey();


        }
    }
}
